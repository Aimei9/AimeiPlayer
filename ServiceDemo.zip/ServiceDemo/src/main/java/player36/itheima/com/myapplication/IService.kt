package player36.itheima.com.myapplication


/**
 * ClassName:IService
 * Description:
 */
interface IService {
    fun callSayHello();
}