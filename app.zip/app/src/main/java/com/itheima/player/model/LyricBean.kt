package com.itheima.player.model


/**
 * ClassName:LyricBean
 * Description:歌词bean
 */
data class LyricBean(val startTime:Int,val content:String)