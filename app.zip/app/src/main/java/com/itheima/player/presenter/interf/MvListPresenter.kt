package com.itheima.player.presenter.interf

import com.itheima.player.base.BaseListPresenter


/**
 * ClassName:MvListPresenter
 * Description:
 */
interface MvListPresenter:BaseListPresenter {
}