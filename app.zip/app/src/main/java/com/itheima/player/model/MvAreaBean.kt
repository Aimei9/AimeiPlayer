package com.itheima.player.model.bean


/**
 * ClassName:MvAreaBean
 * Description:
 */
data class MvAreaBean(var name:String,var code:String)