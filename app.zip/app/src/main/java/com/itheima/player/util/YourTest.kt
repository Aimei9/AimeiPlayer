package com.itheima.player.util


/**
 * ClassName:YourTest
 * Description:
 */
class YourTest:MyTest() {
    fun add(){
        ss
    }
}