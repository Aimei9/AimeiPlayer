package com.itheima.player.view

import com.itheima.player.base.BaseView
import com.itheima.player.model.bean.YueDanBean


/**
 * ClassName:YueDanView
 * Description:
 */
interface YueDanView:BaseView<YueDanBean> {

}