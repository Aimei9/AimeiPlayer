package com.itheima.player.presenter.interf


/**
 * ClassName:MvPresenter
 * Description:
 */
interface MvPresenter {
    fun loadDatas()
}