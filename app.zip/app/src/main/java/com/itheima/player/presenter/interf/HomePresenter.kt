package com.itheima.player.presenter.interf

import com.itheima.player.base.BaseListPresenter


/**
 * ClassName:HomePresenter
 * Description:
 */
interface HomePresenter:BaseListPresenter {

}