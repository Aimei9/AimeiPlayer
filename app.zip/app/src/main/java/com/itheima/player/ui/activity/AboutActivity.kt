package com.itheima.player.ui.activity

import com.itheima.player.R
import com.itheima.player.base.BaseActivity


/**
 * ClassName:AboutActivity
 * Description:
 */
class AboutActivity: BaseActivity() {
    override fun getLayoutId(): Int {
        return R.layout.activity_about
    }
}