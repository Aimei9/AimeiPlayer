package com.itheima.player.util;

/**
 * ClassName:MyTest
 * Description:
 */
public class MyTest {
    public int getSS(){
        return 10;
    }
}
